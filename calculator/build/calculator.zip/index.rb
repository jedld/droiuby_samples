#droiuby ruby script
class Index < Activity
	def on_create
	  #called when activity is first created 
	end
	
	def on_activity_result(request_code, result_code, intent)
	  #callback from starting an activity with result 
	end
end
